///*
// * File: qwindow.h
// * ---------------
// *
// * @version 2018/01/20
// * - initial version
// */

//#ifndef _qwindow_h
//#define _qwindow_h

//#include <string>
//#include <QApplication>

//class QWindow {
//public:
//    QWindow(double width = 0, double height = 0, bool visible = true);
//    virtual ~QWindow();

//    std::string getTitle() const;

//    void setTitle(const std::string& title);

//private:
//    QApplication* _window;
//};

//#endif // _gwindow_h
