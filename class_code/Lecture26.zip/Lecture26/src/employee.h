/*
 * CS 106X, Nick Troccoli
 * This file declares the Employee class, the superclass or base class in
 * our inheritance hierarchy.
 */

#pragma once

#include <string>

// A class to represent employees in general.
class Employee {
public:
    Employee(const std::string& name, int yearsWorked);
    virtual int getHoursWorkedPerWeek() const;
    virtual std::string getName() const;
    int getYearsWorked() const;

private:
    std::string name;
    int yearsWorked;
};
